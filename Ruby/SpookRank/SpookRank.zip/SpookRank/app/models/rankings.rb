class Rankings < ApplicationRecord
end
