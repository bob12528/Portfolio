class Comments < ApplicationRecord
end
