class Database < ApplicationRecord
end
