class Movies < ApplicationRecord
end
