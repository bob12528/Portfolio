README:
Original proposed application was far too complex -- on par with commercial products such as Venmo.
After hours of design and modification, I determined it was impossible to simplify to a reasonable point.
User registration, validation, login, and protections were all immutable, as well as supporting both
usernames, phone numbers, personal names, and nicknames, and mapping them to the same user value. 
This was all upfront difficulty prior to any actual algorithmic operations on data, such as cost
splitting, organization, visualization of the trends in data, etc. 

Instead, I am proposing a Horror Movie Ranking Site, dubbed SpookRank. I plan to discuss this
after class, and anticipate taking the lateness penalty.

Additionally, the server was down since Saturday's 3am oncampus power failure, so I was unable
to upload to the VM, or access a PG server. Due to this, my implementation is incomplete and hard-
coded. I understand that this is either a massive loss of points, or something that necessitates
a lateness penalty and resubmit once the servers are available again. 

Will also need to re-do all of the design documents and test cases for the resubmit of that
assignment, rather than the refinements for the old variant. 